package com.example.b1906314_buichihai_n02

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.b1906314_buichihai.MyData
import com.example.b1906314_buichihai_n02.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var helper: MyData
    lateinit var db: SQLiteDatabase
    lateinit var rs: Cursor
    var selectedId = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // test nút chuyển trang qua QL_Activity
        binding.layout1B1906314.setOnClickListener {
            startActivities(arrayOf(Intent(this, Qly_Activity::class.java)))
        }

        addEvent()

    }

    private fun addEvent() {
        helper = MyData(applicationContext)
        db = helper.readableDatabase
        rs = db.rawQuery("select * from user_b1906314", null)
        if(rs.moveToFirst())
            readData()


    }

    private fun readData() {
        selectedId = rs.getString((0)).toInt()
        binding.tvHoTenB1906314.setText(rs.getString(1))
        binding.tvGtinhB1906314.setText(rs.getString(3))
        binding.tvLopB1906314.setText(rs.getString(4))
        binding.tvDiemB1906314.setText(rs.getString(5))


    }
}