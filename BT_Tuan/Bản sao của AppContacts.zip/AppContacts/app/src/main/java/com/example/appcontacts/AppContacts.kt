package com.example.appcontacts

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.appcontacts.databinding.ActivityAppContactsBinding

class AppContacts : AppCompatActivity() {
    lateinit var binding: ActivityAppContactsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppContactsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = intent.getStringExtra("name")
        val email = intent.getStringExtra("email")
        val city = intent.getStringExtra("city")
        val phone = intent.getStringExtra("phone")


        val img = intent.getStringExtra("img")
        Glide.with(this).load(img).circleCrop().into(binding.im2)

        binding.tvHoten.text = name
        binding.tvEmail.text = email
        binding.tvAddress.text = city
        binding.tvPhone.text = phone
    }
}