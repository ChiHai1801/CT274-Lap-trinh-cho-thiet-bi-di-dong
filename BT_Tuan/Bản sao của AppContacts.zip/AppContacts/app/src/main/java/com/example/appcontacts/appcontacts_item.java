package com.example.appcontacts;

import android.app.Activity;

public class appcontacts_item extends Activity {
}
