package com.example.appcontacts

data class Dulieu(
    val info: Info,
    val results: ArrayList<Result>
)