package com.example.appcontacts

data class Timezone(
    val description: String,
    val offset: String
)