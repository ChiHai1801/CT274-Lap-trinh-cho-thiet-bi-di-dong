package com.example.appcontacts

data class Name(
    val first: String,
    val last: String,
    val title: String
)