package com.example.appcontacts

data class Data(
    val info: Info,
    val results: ArrayList<Dulieu>
)