package com.example.appcontacts

data class Street(
    val name: String,
    val number: Int
)