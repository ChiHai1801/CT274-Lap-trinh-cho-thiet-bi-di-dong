package com.example.appcontacts

data class Registered(
    val age: Int,
    val date: String
)