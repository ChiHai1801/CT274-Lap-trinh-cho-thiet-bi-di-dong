package com.example.appcontacts

data class Dob(
    val age: Int,
    val date: String
)