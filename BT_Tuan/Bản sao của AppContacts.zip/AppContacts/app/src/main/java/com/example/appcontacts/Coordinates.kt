package com.example.appcontacts

data class Coordinates(
    val latitude: String,
    val longitude: String
)